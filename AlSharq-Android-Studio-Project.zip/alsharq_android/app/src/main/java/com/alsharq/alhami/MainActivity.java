package com.alsharq.alhami;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.content.Context;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private TextView offlineMessage;
    private static final String HOME_URL = "https://alsharq1983.netlify.app/";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(this);
        webView = new WebView(this);
        offlineMessage = new TextView(this);
        offlineMessage.setText("لا يوجد اتصال بالإنترنت. تحقق من الاتصال ثم اضغط إعادة المحاولة.");
        offlineMessage.setTextColor(Color.WHITE);
        offlineMessage.setBackgroundColor(Color.rgb(13, 71, 161));
        offlineMessage.setGravity(Gravity.CENTER);
        offlineMessage.setTextSize(18);
        offlineMessage.setPadding(32, 32, 32, 32);
        offlineMessage.setOnClickListener(v -> webView.reload());
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        root.addView(offlineMessage, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setAllowFileAccess(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                offlineMessage.setVisibility(View.GONE);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) {
                    offlineMessage.setVisibility(View.VISIBLE);
                    offlineMessage.setText("تعذر فتح الموقع. تحقق من الإنترنت واضغط هنا لإعادة المحاولة.");
                }
            }
        });
        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
        else webView.loadUrl(HOME_URL);
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
