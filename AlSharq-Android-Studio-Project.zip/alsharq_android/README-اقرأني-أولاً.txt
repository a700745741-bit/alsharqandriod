تطبيق فريق الشرق - مشروع Android Studio

هذا هو مشروع أندرويد أولي (WebView) يفتح الموقع الحالي:
https://alsharq1983.netlify.app/

المشروع لا يغيّر ملفات الموقع أو منشوراته في Firebase. وهو ليس APK جاهزاً بعد.

طريقة البناء:
1) نزّل وفك ضغط AlSharq-Android-Studio-Project.zip.
2) افتح Android Studio واختر Open ثم اختر مجلد AlSharq-Android-Studio-Project.
3) انتظر Gradle Sync. يلزم اتصال إنترنت أول مرة لتنزيل أدوات البناء.
4) من القائمة Build اختر Build APK(s).
5) عند انتهاء البناء افتح رابط Locate أو ابحث داخل app/build/outputs/apk/debug/app-debug.apk.

ملاحظات مهمة:
- المشروع يفتح الموقع الحالي عبر الإنترنت، ولا يضمن عرض كل المحتوى دون إنترنت؛ ذلك يعتمد على كاش الموقع نفسه.
- لا توجد إشعارات دفع FCM مفعّلة في هذا المشروع.
- حماية لوحة الإدارة بكلمة مرور داخل HTML وحدها ليست حماية أمنية حقيقية. يلزم Firebase Authentication وقواعد Firestore مناسبة.
- لم يُبنَ APK فعلياً داخل هذه البيئة؛ المشروع جاهز للفتح والبناء في Android Studio، وقد يطلب Android Studio تحديث Gradle أو SDK حسب نسخته.
